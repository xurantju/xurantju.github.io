#include "weights.h"

int main(int argc, char* argv[]) {
	weight_list w(100, 100);

	return 0;
}
